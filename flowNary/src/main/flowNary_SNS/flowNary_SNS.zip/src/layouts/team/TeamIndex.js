// Material Dashboard 2 React example components
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import Footer from "examples/Footer";


export default function team() {

  return (
    <DashboardLayout>
      <DashboardNavbar />
        팀 멤버 사진 추가 예정


    </DashboardLayout>
  );
}