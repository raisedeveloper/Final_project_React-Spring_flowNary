export { default } from './label';
