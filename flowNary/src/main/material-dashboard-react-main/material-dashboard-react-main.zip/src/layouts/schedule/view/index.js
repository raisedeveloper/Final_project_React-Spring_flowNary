export { default as ScheduleView } from '../ScheduleIndex';
