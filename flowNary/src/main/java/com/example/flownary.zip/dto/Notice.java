package com.example.flownary.dto;

public class Notice {

}
