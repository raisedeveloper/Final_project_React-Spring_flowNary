package com.example.flownary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlownaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlownaryApplication.class, args);
	}

}
